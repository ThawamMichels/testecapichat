import React from 'react';

export default function Contacts() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-[#051021] text-white">
      <h1 className="text-2xl font-bold mb-2">Gestão de Contatos</h1>
      <p className="text-gray-400">Recurso em desenvolvimento para o CapiChat.</p>
    </div>
  );
}