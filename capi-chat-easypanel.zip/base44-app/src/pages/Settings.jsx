import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Webhook, Plus, Trash2, Save, Activity, Check, Smartphone, Link as LinkIcon, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function Settings() {
  const queryClient = useQueryClient();
  // Webhooks State
  const [newWebhook, setNewWebhook] = useState({ name: '', url: '' });
  // Channels State
  const [newChannel, setNewChannel] = useState({ 
    name: '', 
    provider: 'evolution_api', 
    base_url: '', 
    api_key: '', 
    instance_name: '' 
  });

  // Queries
  const { data: webhooks = [] } = useQuery({
    queryKey: ['webhooks'],
    queryFn: () => base44.entities.Webhook.list(),
  });

  const { data: channels = [] } = useQuery({
    queryKey: ['channels'],
    queryFn: () => base44.entities.ChannelConfig.list(),
  });

  // Webhook Mutations
  const createWebhookMutation = useMutation({
    mutationFn: (data) => base44.entities.Webhook.create({
      ...data,
      events: ['message_created', 'conversation_created'],
      active: true
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['webhooks']);
      setNewWebhook({ name: '', url: '' });
      toast.success('Webhook criado com sucesso!');
    }
  });

  const deleteWebhookMutation = useMutation({
    mutationFn: (id) => base44.entities.Webhook.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['webhooks']);
      toast.success('Webhook removido.');
    }
  });

  const toggleWebhookMutation = useMutation({
    mutationFn: ({ id, active }) => base44.entities.Webhook.update(id, { active }),
    onSuccess: () => queryClient.invalidateQueries(['webhooks'])
  });

  // Channel Mutations
  const createChannelMutation = useMutation({
    mutationFn: (data) => base44.entities.ChannelConfig.create({
      ...data,
      status: 'active'
    }),
    onSuccess: () => {
      queryClient.invalidateQueries(['channels']);
      setNewChannel({ name: '', provider: 'evolution_api', base_url: '', api_key: '', instance_name: '' });
      toast.success('Canal WhatsApp conectado com sucesso!');
    }
  });

  const deleteChannelMutation = useMutation({
    mutationFn: (id) => base44.entities.ChannelConfig.delete(id),
    onSuccess: () => {
      queryClient.invalidateQueries(['channels']);
      toast.success('Canal removido.');
    }
  });

  // Handlers
  const handleWebhookSubmit = (e) => {
    e.preventDefault();
    if (newWebhook.name && newWebhook.url) {
      createWebhookMutation.mutate(newWebhook);
    }
  };

  const handleChannelSubmit = (e) => {
    e.preventDefault();
    if (newChannel.name && newChannel.base_url && newChannel.api_key) {
      createChannelMutation.mutate(newChannel);
    }
  };

  return (
    <div className="p-8 max-w-5xl mx-auto w-full">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-2">Configurações</h1>
        <p className="text-gray-400">Gerencie canais, integrações e automações do CapiChat.</p>
      </div>

      <Tabs defaultValue="channels" className="w-full">
        <TabsList className="bg-[#0a192f] border-orange-500/20 border mb-8">
            <TabsTrigger value="channels" className="data-[state=active]:bg-teal-600 data-[state=active]:text-white">Canais WhatsApp</TabsTrigger>
            <TabsTrigger value="webhooks" className="data-[state=active]:bg-teal-600 data-[state=active]:text-white">Webhooks & n8n</TabsTrigger>
            <TabsTrigger value="tags" className="data-[state=active]:bg-teal-600 data-[state=active]:text-white">Tags & Customização</TabsTrigger>
        </TabsList>

        {/* --- ABA CANAIS WHATSAPP --- */}
        <TabsContent value="channels">
            <Card className="bg-[#0a192f] border-orange-500/20 text-white shadow-lg shadow-blue-900/10">
                <CardHeader>
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-green-500/10 rounded-lg">
                            <Smartphone className="w-6 h-6 text-green-400" />
                        </div>
                        <div>
                            <CardTitle className="text-xl">Conexões WhatsApp API</CardTitle>
                            <CardDescription className="text-gray-400">
                                Conecte instâncias do Evolution API, Waha ou API Oficial para enviar e receber mensagens.
                            </CardDescription>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        {/* Form Canal */}
                        <div className="bg-[#051021] p-4 rounded-xl border border-white/5">
                            <h3 className="text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
                                <Plus className="w-4 h-4 text-orange-500" /> Adicionar Nova Conexão
                            </h3>
                            <form onSubmit={handleChannelSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                <div className="space-y-2">
                                    <Label className="text-xs text-gray-500">Nome do Canal</Label>
                                    <Input 
                                        placeholder="Ex: WhatsApp Vendas" 
                                        value={newChannel.name}
                                        onChange={(e) => setNewChannel({...newChannel, name: e.target.value})}
                                        className="bg-[#0a192f] border-orange-500/20 text-white"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-xs text-gray-500">Provedor</Label>
                                    <Select 
                                        value={newChannel.provider} 
                                        onValueChange={(val) => setNewChannel({...newChannel, provider: val})}
                                    >
                                        <SelectTrigger className="bg-[#0a192f] border-orange-500/20 text-white">
                                            <SelectValue />
                                        </SelectTrigger>
                                        <SelectContent className="bg-[#0a192f] border-orange-500/20 text-white">
                                            <SelectItem value="evolution_api">Evolution API</SelectItem>
                                            <SelectItem value="waha">Waha (WhatsApp HTTP API)</SelectItem>
                                            <SelectItem value="official_cloud">WhatsApp Cloud API (Meta)</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-xs text-gray-500">Base URL da API</Label>
                                    <Input 
                                        placeholder="https://api.seuserver.com" 
                                        value={newChannel.base_url}
                                        onChange={(e) => setNewChannel({...newChannel, base_url: e.target.value})}
                                        className="bg-[#0a192f] border-orange-500/20 text-white font-mono text-sm"
                                    />
                                </div>
                                <div className="space-y-2">
                                    <Label className="text-xs text-gray-500">API Key / Token</Label>
                                    <Input 
                                        type="password"
                                        placeholder="••••••••••••••" 
                                        value={newChannel.api_key}
                                        onChange={(e) => setNewChannel({...newChannel, api_key: e.target.value})}
                                        className="bg-[#0a192f] border-orange-500/20 text-white font-mono text-sm"
                                    />
                                </div>
                                <div className="space-y-2 md:col-span-2">
                                    <Label className="text-xs text-gray-500">Nome da Instância (Opcional - Evolution/Waha)</Label>
                                    <Input 
                                        placeholder="Ex: Instancia01" 
                                        value={newChannel.instance_name}
                                        onChange={(e) => setNewChannel({...newChannel, instance_name: e.target.value})}
                                        className="bg-[#0a192f] border-orange-500/20 text-white"
                                    />
                                </div>
                                <div className="md:col-span-2 flex justify-end mt-2">
                                    <Button 
                                        type="submit" 
                                        disabled={!newChannel.name || !newChannel.base_url || !newChannel.api_key}
                                        className="bg-green-600 hover:bg-green-700 text-white"
                                    >
                                        <LinkIcon className="w-4 h-4 mr-2" /> Conectar Canal
                                    </Button>
                                </div>
                            </form>
                        </div>

                        {/* Lista Canais */}
                        <div className="space-y-3">
                            <h3 className="text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                                <Activity className="w-4 h-4 text-green-500" /> Canais Configurados
                            </h3>
                            {channels.length === 0 && (
                                <div className="text-center py-8 text-gray-500 italic border border-dashed border-gray-700 rounded-xl">
                                    Nenhum canal de WhatsApp conectado.
                                </div>
                            )}
                            {channels.map((channel) => (
                                <div key={channel.id} className="flex items-center justify-between p-4 bg-[#051021] rounded-xl border border-white/5 hover:border-green-500/30 transition-all">
                                    <div>
                                        <div className="flex items-center gap-3">
                                            <span className="font-semibold text-white">{channel.name}</span>
                                            <Badge variant="outline" className="border-teal-500/30 text-teal-400 text-[10px] uppercase">
                                                {channel.provider}
                                            </Badge>
                                        </div>
                                        <div className="flex flex-col gap-1 mt-1">
                                            <code className="text-xs text-gray-500">{channel.base_url}</code>
                                            {channel.instance_name && <span className="text-xs text-gray-600">Instância: {channel.instance_name}</span>}
                                        </div>
                                    </div>
                                    <Button 
                                        size="icon" 
                                        variant="ghost" 
                                        className="text-gray-500 hover:text-red-400 hover:bg-red-500/10"
                                        onClick={() => deleteChannelMutation.mutate(channel.id)}
                                    >
                                        <Trash2 className="w-4 h-4" />
                                    </Button>
                                </div>
                            ))}
                        </div>

                        <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-xl text-sm text-yellow-200 flex gap-3">
                            <AlertCircle className="w-5 h-5 flex-shrink-0 text-yellow-500" />
                            <div>
                                <p className="font-bold mb-1">Como integrar:</p>
                                <p className="opacity-80">
                                    Após adicionar o canal aqui, você deve configurar o <strong>Webhook</strong> na sua plataforma (Evolution/Waha) para apontar para a URL do seu n8n, e o n8n deve repassar os dados para o CapiChat via API.
                                </p>
                            </div>
                        </div>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>

        {/* --- ABA WEBHOOKS --- */}
        <TabsContent value="webhooks">
            <Card className="bg-[#0a192f] border-orange-500/20 text-white shadow-lg shadow-blue-900/10">
                <CardHeader>
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-teal-500/10 rounded-lg">
                            <Webhook className="w-6 h-6 text-teal-400" />
                        </div>
                        <div>
                            <CardTitle className="text-xl">Integração n8n & Webhooks</CardTitle>
                            <CardDescription className="text-gray-400">
                                Configure URLs para onde enviaremos eventos de chat (mensagens, novas conversas).
                            </CardDescription>
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <div className="space-y-6">
                        {/* Form Webhook */}
                        <div className="bg-[#051021] p-4 rounded-xl border border-white/5">
                            <h3 className="text-sm font-medium text-gray-300 mb-4 flex items-center gap-2">
                                <Plus className="w-4 h-4 text-orange-500" /> Adicionar Novo Endpoint
                            </h3>
                            <form onSubmit={handleWebhookSubmit} className="flex gap-4 items-end flex-wrap">
                                <div className="flex-1 min-w-[200px] space-y-2">
                                    <Label htmlFor="wb-name" className="text-xs text-gray-500">Nome</Label>
                                    <Input 
                                        id="wb-name"
                                        placeholder="Ex: n8n Production" 
                                        value={newWebhook.name}
                                        onChange={(e) => setNewWebhook({...newWebhook, name: e.target.value})}
                                        className="bg-[#0a192f] border-orange-500/20 text-white"
                                    />
                                </div>
                                <div className="flex-[2] min-w-[300px] space-y-2">
                                    <Label htmlFor="wb-url" className="text-xs text-gray-500">Webhook URL (POST)</Label>
                                    <Input 
                                        id="wb-url"
                                        placeholder="https://n8n.seuservidor.com/webhook/..." 
                                        value={newWebhook.url}
                                        onChange={(e) => setNewWebhook({...newWebhook, url: e.target.value})}
                                        className="bg-[#0a192f] border-orange-500/20 text-white font-mono text-sm"
                                    />
                                </div>
                                <Button 
                                    type="submit" 
                                    disabled={!newWebhook.name || !newWebhook.url}
                                    className="bg-teal-600 hover:bg-teal-700 text-white"
                                >
                                    <Save className="w-4 h-4 mr-2" /> Salvar
                                </Button>
                            </form>
                        </div>

                        {/* Lista Webhooks */}
                        <div className="space-y-3">
                            <h3 className="text-sm font-medium text-gray-300 mb-2 flex items-center gap-2">
                                <Activity className="w-4 h-4 text-teal-500" /> Webhooks Ativos
                            </h3>
                            {webhooks.length === 0 && (
                                <div className="text-center py-8 text-gray-500 italic border border-dashed border-gray-700 rounded-xl">
                                    Nenhum webhook configurado.
                                </div>
                            )}
                            {webhooks.map((hook) => (
                                <div key={hook.id} className="flex items-center justify-between p-4 bg-[#051021] rounded-xl border border-white/5 hover:border-teal-500/30 transition-all">
                                    <div className="flex-1">
                                        <div className="flex items-center gap-3">
                                            <span className="font-semibold text-white">{hook.name}</span>
                                            <Badge variant={hook.active ? "default" : "secondary"} className={hook.active ? "bg-green-500/20 text-green-400 hover:bg-green-500/30" : "bg-gray-700 text-gray-400"}>
                                                {hook.active ? 'Ativo' : 'Inativo'}
                                            </Badge>
                                        </div>
                                        <code className="text-xs text-gray-500 mt-1 block truncate max-w-lg">{hook.url}</code>
                                    </div>
                                    
                                    <div className="flex items-center gap-4">
                                        <div className="flex items-center gap-2">
                                            <Switch 
                                                checked={hook.active}
                                                onCheckedChange={(checked) => toggleWebhookMutation.mutate({ id: hook.id, active: checked })}
                                                className="data-[state=checked]:bg-teal-500"
                                            />
                                        </div>
                                        <Button 
                                            size="icon" 
                                            variant="ghost" 
                                            className="text-gray-500 hover:text-red-400 hover:bg-red-500/10"
                                            onClick={() => deleteWebhookMutation.mutate(hook.id)}
                                        >
                                            <Trash2 className="w-4 h-4" />
                                        </Button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>

        {/* --- ABA TAGS --- */}
        <TabsContent value="tags">
            <Card className="bg-[#0a192f] border-orange-500/20 text-white opacity-90">
                <CardHeader>
                    <CardTitle className="text-lg">Personalização de Tags</CardTitle>
                    <CardDescription className="text-gray-400">
                        Gerencie as etiquetas disponíveis para categorizar conversas.
                    </CardDescription>
                </CardHeader>
                <CardContent>
                    <div className="p-8 bg-[#051021] rounded-xl border border-dashed border-gray-700 text-center">
                        <p className="text-gray-400 mb-4">Esta funcionalidade está disponível diretamente no painel de administração.</p>
                        <Button variant="outline" className="border-teal-500 text-teal-400 hover:bg-teal-500/10">
                            Gerenciar Tags
                        </Button>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}