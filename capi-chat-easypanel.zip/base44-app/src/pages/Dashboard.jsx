import React, { useState, useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { 
  Search, Filter, Send, Paperclip, MoreVertical, 
  CheckCircle2, Clock, Hash, UserPlus, ArrowRightLeft,
  Tag as TagIcon, Smile, Phone, Mail, MessageSquare
} from 'lucide-react';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";

// Componente de Chat
export default function Dashboard() {
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messageInput, setMessageInput] = useState('');
  const [activeTab, setActiveTab] = useState('mine'); // 'mine', 'all', 'resolved'
  const [newConvData, setNewConvData] = useState({ name: '', email: '', channel: 'web' });
  const [isNewConvOpen, setIsNewConvOpen] = useState(false);
  const messagesEndRef = useRef(null);
  const queryClient = useQueryClient();
  const [currentUser, setCurrentUser] = useState(null);

  // Buscar usuário atual
  useEffect(() => {
    async function loadUser() {
      try {
        const user = await base44.auth.me();
        setCurrentUser(user);
      } catch (e) {
        console.error("User not logged in");
      }
    }
    loadUser();
  }, []);

  // Queries
  const { data: conversations = [] } = useQuery({
    queryKey: ['conversations'],
    queryFn: () => base44.entities.Conversation.list('-last_message_at'),
    refetchInterval: 5000 // Polling para "tempo real"
  });

  const { data: messages = [] } = useQuery({
    queryKey: ['messages', selectedConversation?.id],
    queryFn: () => selectedConversation 
      ? base44.entities.Message.filter({ conversation_id: selectedConversation.id }, 'created_date', 100)
      : [],
    enabled: !!selectedConversation,
    refetchInterval: 3000
  });

  const { data: availableTags = [] } = useQuery({
    queryKey: ['tags'],
    queryFn: () => base44.entities.Tag.list(),
  });

  const { data: users = [] } = useQuery({
    queryKey: ['users'],
    queryFn: () => base44.entities.User.list(), // Requer permissão de admin geralmente, mas vamos tentar
  });

  // Mutations
  const sendMessageMutation = useMutation({
    mutationFn: (data) => base44.functions.invoke('sendMessage', data),
    onSuccess: () => {
      queryClient.invalidateQueries(['messages']);
      queryClient.invalidateQueries(['conversations']);
      setMessageInput('');
      scrollToBottom();
    }
  });

  const updateConversationMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Conversation.update(id, data),
    onSuccess: () => queryClient.invalidateQueries(['conversations'])
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Handlers
  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!messageInput.trim() || !selectedConversation) return;

    sendMessageMutation.mutate({
      conversation_id: selectedConversation.id,
      content: messageInput,
      sender_type: 'agent',
      sender_name: currentUser?.full_name || 'Agente',
      read_at: null,
      private: false
    });
  };

  const handleStatusChange = (status) => {
    if (!selectedConversation) return;
    updateConversationMutation.mutate({
      id: selectedConversation.id,
      data: { status }
    });
  };

  const handleTransfer = (newAgentEmail) => {
    if (!selectedConversation) return;
    updateConversationMutation.mutate({
      id: selectedConversation.id,
      data: { assigned_to: newAgentEmail }
    });
  };

  const handleAddTag = (tagName) => {
    if (!selectedConversation) return;
    const currentTags = selectedConversation.tags || [];
    if (!currentTags.includes(tagName)) {
      updateConversationMutation.mutate({
        id: selectedConversation.id,
        data: { tags: [...currentTags, tagName] }
      });
    }
  };

  const handleRemoveTag = (tagName) => {
    if (!selectedConversation) return;
    const currentTags = selectedConversation.tags || [];
    updateConversationMutation.mutate({
      id: selectedConversation.id,
      data: { tags: currentTags.filter(t => t !== tagName) }
    });
  };

  // Filtragem
  const filteredConversations = conversations.filter(c => {
    if (activeTab === 'resolved') return c.status === 'resolved';
    if (activeTab === 'mine') return c.assigned_to === currentUser?.email && c.status !== 'resolved';
    return c.status !== 'resolved';
  });

  return (
    <div className="flex h-full w-full bg-[#051021]">
      {/* Lista de Conversas */}
      <div className="w-80 lg:w-96 flex flex-col border-r border-orange-500/20 bg-[#0a192f]">
        <div className="p-4 border-b border-orange-500/20 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-white">Conversas</h2>
            <div className="flex gap-1">
               <Button size="icon" variant="ghost" className="text-gray-400 hover:text-teal-400">
                 <Filter className="w-5 h-5" />
               </Button>
               <Dialog open={isNewConvOpen} onOpenChange={setIsNewConvOpen}>
                 <DialogTrigger asChild>
                   <Button size="icon" variant="ghost" className="text-gray-400 hover:text-teal-400">
                     <UserPlus className="w-5 h-5" />
                   </Button>
                 </DialogTrigger>
                 <DialogContent className="bg-[#0f2442] text-white border-orange-500/30">
                   <DialogHeader>
                     <DialogTitle>Nova Conversa</DialogTitle>
                     <DialogDescription className="text-gray-400">Inicie uma nova conversa via Web ou WhatsApp</DialogDescription>
                   </DialogHeader>
                   <div className="space-y-4 py-4">
                     <div className="space-y-2">
                        <label className="text-xs text-gray-400">Canal</label>
                        <Select 
                            value={newConvData.channel} 
                            onValueChange={(val) => setNewConvData({...newConvData, channel: val})}
                        >
                            <SelectTrigger className="bg-[#051021] border-orange-500/20 text-white">
                                <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="bg-[#0f2442] border-orange-500/30 text-white">
                                <SelectItem value="web">Web Chat (Interno)</SelectItem>
                                <SelectItem value="whatsapp">WhatsApp</SelectItem>
                            </SelectContent>
                        </Select>
                     </div>
                     <div className="space-y-2">
                        <label className="text-xs text-gray-400">
                            {newConvData.channel === 'whatsapp' ? 'Número do Telefone (com DDI)' : 'Nome do Contato'}
                        </label>
                        <Input 
                            placeholder={newConvData.channel === 'whatsapp' ? "Ex: 5511999999999" : "Nome do Cliente"} 
                            className="bg-[#051021] border-orange-500/20" 
                            value={newConvData.name}
                            onChange={(e) => setNewConvData({...newConvData, name: e.target.value})}
                        />
                     </div>
                     <div className="space-y-2">
                        <label className="text-xs text-gray-400">Email (Opcional)</label>
                        <Input 
                            placeholder="Email" 
                            className="bg-[#051021] border-orange-500/20" 
                            value={newConvData.email}
                            onChange={(e) => setNewConvData({...newConvData, email: e.target.value})}
                        />
                     </div>
                   </div>
                   <DialogFooter>
                     <Button className="bg-teal-600 hover:bg-teal-700 text-white" onClick={() => {
                        if(newConvData.name) {
                            base44.entities.Conversation.create({
                                contact_name: newConvData.name,
                                contact_email: newConvData.email || '',
                                status: 'open',
                                channel: newConvData.channel,
                                assigned_to: currentUser?.email,
                                last_message_at: new Date().toISOString()
                            }).then(() => {
                                queryClient.invalidateQueries(['conversations']);
                                setIsNewConvOpen(false);
                                setNewConvData({ name: '', email: '', channel: 'web' });
                                toast.success('Conversa criada com sucesso!');
                            });
                        }
                     }}>Criar & Iniciar</Button>
                   </DialogFooter>
                 </DialogContent>
               </Dialog>
            </div>
          </div>
          
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-500" />
            <Input 
              placeholder="Buscar..." 
              className="pl-9 bg-[#051021] border-orange-500/20 text-gray-300 placeholder:text-gray-600 focus-visible:ring-teal-500/50"
            />
          </div>

          <div className="flex p-1 bg-[#051021] rounded-lg">
            {['mine', 'all', 'resolved'].map(tab => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`flex-1 py-1.5 text-xs font-medium rounded-md transition-all ${
                  activeTab === tab 
                    ? 'bg-teal-500/20 text-teal-400 shadow-sm' 
                    : 'text-gray-500 hover:text-gray-300'
                }`}
              >
                {tab === 'mine' ? 'Minhas' : tab === 'all' ? 'Todas' : 'Resolvidas'}
              </button>
            ))}
          </div>
        </div>

        <ScrollArea className="flex-1">
          <div className="flex flex-col">
            {filteredConversations.map(conv => (
              <div 
                key={conv.id}
                onClick={() => setSelectedConversation(conv)}
                className={`p-4 border-b border-white/5 cursor-pointer hover:bg-white/5 transition-colors ${
                  selectedConversation?.id === conv.id ? 'bg-blue-900/20 border-l-4 border-l-teal-500' : 'border-l-4 border-l-transparent'
                }`}
              >
                <div className="flex justify-between items-start mb-1">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10 border border-orange-500/30">
                      <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${conv.contact_name}`} />
                      <AvatarFallback className="bg-teal-900 text-teal-200">{conv.contact_name?.[0]}</AvatarFallback>
                    </Avatar>
                    <div>
                      <h3 className={`font-semibold text-sm ${selectedConversation?.id === conv.id ? 'text-teal-400' : 'text-gray-200'}`}>
                        {conv.contact_name}
                      </h3>
                      <span className="text-xs text-gray-500 capitalize flex items-center gap-1">
                        {conv.channel === 'whatsapp' && <span className="w-2 h-2 rounded-full bg-green-500"></span>}
                        {conv.channel}
                      </span>
                    </div>
                  </div>
                  <span className="text-xs text-gray-600">
                    {conv.last_message_at && format(new Date(conv.last_message_at), 'HH:mm')}
                  </span>
                </div>
                <p className="text-sm text-gray-400 line-clamp-1 mt-2 pl-13">
                  {conv.last_message || "Inicie a conversa..."}
                </p>
                {conv.tags && conv.tags.length > 0 && (
                  <div className="flex gap-1 mt-2 flex-wrap">
                    {conv.tags.slice(0, 3).map(tag => {
                        const tagInfo = availableTags.find(t => t.name === tag);
                        return (
                            <span key={tag} className="text-[10px] px-1.5 py-0.5 rounded border" style={{ 
                                borderColor: tagInfo?.color || '#666', 
                                color: tagInfo?.color || '#ccc',
                                backgroundColor: `${tagInfo?.color || '#666'}10`
                            }}>
                                {tag}
                            </span>
                        );
                    })}
                  </div>
                )}
              </div>
            ))}
            {filteredConversations.length === 0 && (
                <div className="p-8 text-center text-gray-500">
                    <p>Nenhuma conversa encontrada</p>
                </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Janela de Chat */}
      {selectedConversation ? (
        <div className="flex-1 flex flex-col bg-[#051021] relative">
          {/* Header */}
          <header className="h-16 border-b border-orange-500/20 flex items-center justify-between px-6 bg-[#0a192f]">
            <div className="flex items-center gap-3">
              <Avatar className="h-9 w-9 ring-2 ring-orange-500/20">
                <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${selectedConversation.contact_name}`} />
                <AvatarFallback>CN</AvatarFallback>
              </Avatar>
              <div>
                <h2 className="font-bold text-white flex items-center gap-2">
                  {selectedConversation.contact_name}
                  <Badge variant="outline" className={`
                    ${selectedConversation.status === 'open' ? 'border-green-500 text-green-500' : ''}
                    ${selectedConversation.status === 'pending' ? 'border-yellow-500 text-yellow-500' : ''}
                    ${selectedConversation.status === 'resolved' ? 'border-gray-500 text-gray-500' : ''}
                  `}>
                    {selectedConversation.status === 'open' ? 'Aberto' : selectedConversation.status === 'pending' ? 'Pendente' : 'Resolvido'}
                  </Badge>
                </h2>
                {selectedConversation.contact_email && <p className="text-xs text-gray-400">{selectedConversation.contact_email}</p>}
              </div>
            </div>
            
            <div className="flex items-center gap-2">
              <Popover>
                <PopoverTrigger asChild>
                    <Button variant="ghost" size="sm" className="text-gray-400 hover:text-teal-400">
                        <ArrowRightLeft className="w-4 h-4 mr-2" />
                        Transferir
                    </Button>
                </PopoverTrigger>
                <PopoverContent className="w-64 bg-[#0f2442] border-orange-500/30 text-white p-2">
                    <p className="text-xs text-gray-400 mb-2 px-1">Transferir para agente:</p>
                    {users.length > 0 ? (
                        <div className="space-y-1">
                            {users.map(u => (
                                <button key={u.id} onClick={() => handleTransfer(u.email)} className="w-full text-left px-2 py-1.5 hover:bg-white/5 rounded text-sm flex items-center gap-2">
                                    <div className="w-4 h-4 rounded-full bg-teal-500 flex items-center justify-center text-[10px]">{u.full_name?.[0]}</div>
                                    {u.full_name || u.email}
                                </button>
                            ))}
                        </div>
                    ) : (
                        <div className="text-xs text-gray-500 px-1">Nenhum outro agente disponível.</div>
                    )}
                </PopoverContent>
              </Popover>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-gray-400 hover:text-white">
                    <CheckCircle2 className="w-5 h-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="bg-[#0f2442] border-orange-500/30 text-white">
                  <DropdownMenuItem onClick={() => handleStatusChange('open')}>Marcar como Aberto</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleStatusChange('pending')}>Marcar como Pendente</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleStatusChange('resolved')}>Marcar como Resolvido</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </header>

          {/* Messages Area */}
          <ScrollArea className="flex-1 p-6">
            <div className="space-y-6">
              {messages.length === 0 && (
                <div className="flex flex-col items-center justify-center h-40 opacity-50">
                    <Clock className="w-10 h-10 mb-2 text-teal-500/50" />
                    <p className="text-sm text-gray-400">Início da conversa</p>
                </div>
              )}
              
              {/* Agrupamento de mensagens por data poderia ser feito aqui */}
              
              {messages.map((msg) => {
                const isMe = msg.sender_type === 'agent';
                return (
                  <div key={msg.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <div className={`flex flex-col max-w-[70%] ${isMe ? 'items-end' : 'items-start'}`}>
                      <div className={`px-4 py-3 rounded-2xl shadow-sm ${
                        isMe 
                          ? 'bg-teal-600 text-white rounded-br-none' 
                          : 'bg-[#1e293b] text-gray-100 rounded-bl-none border border-white/5'
                      }`}>
                        <p className="text-sm leading-relaxed">{msg.content}</p>
                      </div>
                      <span className="text-[10px] text-gray-500 mt-1 px-1">
                        {msg.sender_name} • {format(new Date(msg.created_date), 'HH:mm')}
                      </span>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {/* Input Area */}
          <div className="p-4 bg-[#0a192f] border-t border-orange-500/20">
            <form onSubmit={handleSendMessage} className="flex gap-3 items-end">
              <Button type="button" size="icon" variant="ghost" className="text-gray-400 hover:text-teal-400">
                <Paperclip className="w-5 h-5" />
              </Button>
              <div className="flex-1 relative">
                <Input
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  placeholder="Digite sua mensagem... (Enter para enviar)"
                  className="bg-[#051021] border-orange-500/20 text-white placeholder:text-gray-600 pr-10 min-h-[45px] py-3 rounded-xl focus-visible:ring-teal-500"
                />
                <Button 
                    type="button" 
                    size="icon" 
                    variant="ghost" 
                    className="absolute right-1 top-1 h-9 w-9 text-gray-400 hover:text-yellow-400"
                >
                    <Smile className="w-5 h-5" />
                </Button>
              </div>
              <Button 
                type="submit" 
                disabled={!messageInput.trim()}
                className="bg-orange-500 hover:bg-orange-600 text-white rounded-xl h-[45px] w-[45px] p-0 shadow-[0_0_10px_rgba(249,115,22,0.4)]"
              >
                <Send className="w-5 h-5 ml-0.5" />
              </Button>
            </form>
          </div>

          {/* Right Sidebar (Info) - Collapsible on small screens, fixed on large */}
          <div className="absolute right-0 top-16 bottom-0 w-72 bg-[#020b18] border-l border-orange-500/20 transform translate-x-full lg:translate-x-0 transition-transform hidden xl:block">
             <div className="p-6">
                <div className="text-center mb-6">
                    <Avatar className="h-20 w-20 mx-auto mb-3 ring-2 ring-teal-500/50">
                        <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${selectedConversation.contact_name}`} />
                        <AvatarFallback>CN</AvatarFallback>
                    </Avatar>
                    <h3 className="font-bold text-lg text-white">{selectedConversation.contact_name}</h3>
                    {selectedConversation.contact_email && <p className="text-sm text-gray-400">{selectedConversation.contact_email}</p>}
                </div>

                <div className="space-y-6">
                    <div>
                        <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Informações de Contato</h4>
                        <div className="space-y-3">
                            {selectedConversation.contact_email && (
                                <div className="flex items-center gap-3 text-sm text-gray-300">
                                    <Mail className="w-4 h-4 text-teal-500" />
                                    <span className="truncate">{selectedConversation.contact_email}</span>
                                </div>
                            )}
                            <div className="flex items-center gap-3 text-sm text-gray-300">
                                <Phone className="w-4 h-4 text-teal-500" />
                                <span>+55 11 99999-9999</span>
                            </div>
                        </div>
                    </div>

                    <Separator className="bg-white/10" />

                    <div>
                        <div className="flex items-center justify-between mb-3">
                            <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Tags</h4>
                            <Popover>
                                <PopoverTrigger asChild>
                                    <Button variant="ghost" size="icon" className="h-6 w-6 text-gray-400 hover:text-teal-400">
                                        <TagIcon className="w-3 h-3" />
                                    </Button>
                                </PopoverTrigger>
                                <PopoverContent className="w-48 bg-[#0f2442] border-orange-500/30 text-white p-1">
                                    {availableTags.map(tag => (
                                        <button 
                                            key={tag.id}
                                            onClick={() => handleAddTag(tag.name)}
                                            className="w-full text-left px-2 py-1.5 hover:bg-white/5 rounded text-sm flex items-center gap-2"
                                        >
                                            <div className="w-2 h-2 rounded-full" style={{ background: tag.color }} />
                                            {tag.name}
                                        </button>
                                    ))}
                                </PopoverContent>
                            </Popover>
                        </div>
                        <div className="flex flex-wrap gap-2">
                            {selectedConversation.tags?.map(tagName => {
                                const tagInfo = availableTags.find(t => t.name === tagName);
                                return (
                                    <Badge 
                                        key={tagName} 
                                        variant="outline" 
                                        className="pl-2 pr-1 py-1 gap-1"
                                        style={{ 
                                            borderColor: tagInfo?.color || '#666', 
                                            color: tagInfo?.color || '#ccc',
                                            backgroundColor: `${tagInfo?.color || '#666'}10`
                                        }}
                                    >
                                        {tagName}
                                        <button onClick={() => handleRemoveTag(tagName)} className="hover:text-white ml-1">
                                            <span className="sr-only">Remover</span>
                                            ×
                                        </button>
                                    </Badge>
                                );
                            })}
                            {(!selectedConversation.tags || selectedConversation.tags.length === 0) && (
                                <span className="text-xs text-gray-600 italic">Sem tags</span>
                            )}
                        </div>
                    </div>
                </div>
             </div>
          </div>

        </div>
      ) : (
        <div className="flex-1 flex flex-col items-center justify-center bg-[#051021] text-center p-8">
           <div className="w-24 h-24 bg-blue-900/20 rounded-full flex items-center justify-center mb-6 animate-pulse">
             <MessageSquare className="w-10 h-10 text-teal-500" />
           </div>
           <h1 className="text-3xl font-bold text-white mb-2">Bem-vindo ao Capi<span className="text-teal-400">Chat</span></h1>
           <p className="text-gray-400 max-w-md">
             Selecione uma conversa ao lado para começar o atendimento ou aguarde novas mensagens.
           </p>
        </div>
      )}
    </div>
  );
}