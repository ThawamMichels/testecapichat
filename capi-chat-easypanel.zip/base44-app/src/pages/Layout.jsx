
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { MessageSquare, Settings, Users, BarChart3, LogOut, Hexagon } from 'lucide-react';
import { base44 } from '@/api/base44Client';

export default function Layout({ children }) {
  const location = useLocation();

  // Cores Baseadas no pedido:
  // Royal Blue Background: bg-[#0a192f] (Deep Royal) ou bg-blue-950
  // Emerald Highlight: text-teal-400
  // Orange Secondary: border-orange-500

  const navItems = [
    { icon: MessageSquare, label: 'Conversas', path: 'Dashboard' },
    { icon: Users, label: 'Contatos', path: 'Contacts' }, // Placeholder
    { icon: Settings, label: 'Configurações', path: 'Settings' },
  ];

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  return (
    <div className="flex h-screen w-full bg-[#051021] text-white font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-20 lg:w-64 flex-shrink-0 border-r border-orange-500/20 bg-[#020b18] flex flex-col justify-between transition-all duration-300">
        <div>
          <div className="h-16 flex items-center justify-center lg:justify-start lg:px-6 border-b border-orange-500/20">
            <div className="w-8 h-8 bg-gradient-to-br from-teal-400 to-blue-600 rounded-lg flex items-center justify-center mr-0 lg:mr-3 shadow-[0_0_15px_rgba(45,212,191,0.3)]">
              <Hexagon className="w-5 h-5 text-white fill-current" />
            </div>
            <span className="hidden lg:block font-bold text-xl tracking-tight text-white">
              Capi<span className="text-teal-400">Chat</span>
            </span>
          </div>

          <nav className="mt-6 px-2 space-y-2">
            {navItems.map((item) => {
              const isActive = location.pathname.includes(item.path) || (item.path === 'Dashboard' && location.pathname === '/');
              return (
                <Link
                  key={item.path}
                  to={createPageUrl(item.path)}
                  className={`flex items-center px-3 py-3 rounded-xl transition-all duration-200 group ${
                    isActive 
                      ? 'bg-blue-900/40 text-teal-400 shadow-[inset_0_0_0_1px_rgba(45,212,191,0.2)]' 
                      : 'text-gray-400 hover:text-white hover:bg-white/5'
                  }`}
                >
                  <item.icon className={`w-6 h-6 lg:mr-3 ${isActive ? 'text-teal-400 drop-shadow-[0_0_3px_rgba(45,212,191,0.5)]' : 'group-hover:text-orange-400 transition-colors'}`} />
                  <span className="hidden lg:block font-medium">{item.label}</span>
                  {isActive && <div className="ml-auto w-1.5 h-1.5 rounded-full bg-orange-500 hidden lg:block shadow-[0_0_5px_rgba(249,115,22,0.8)]" />}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-orange-500/20">
          <button 
            onClick={handleLogout}
            className="flex items-center w-full px-3 py-3 rounded-xl text-gray-400 hover:text-red-400 hover:bg-red-500/10 transition-all duration-200"
          >
            <LogOut className="w-6 h-6 lg:mr-3" />
            <span className="hidden lg:block font-medium">Sair</span>
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-teal-400 via-blue-500 to-orange-500 z-50 opacity-80" />
        {children}
      </main>
    </div>
  );
}
