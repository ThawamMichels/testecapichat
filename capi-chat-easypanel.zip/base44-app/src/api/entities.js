import { base44 } from './base44Client';


export const Conversation = base44.entities.Conversation;

export const Message = base44.entities.Message;

export const Tag = base44.entities.Tag;

export const Webhook = base44.entities.Webhook;

export const ChannelConfig = base44.entities.ChannelConfig;



// auth sdk:
export const User = base44.auth;