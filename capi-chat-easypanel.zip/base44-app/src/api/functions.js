import { base44 } from './base44Client';


export const sendMessage = base44.functions.sendMessage;

export const whatsappWebhook = base44.functions.whatsappWebhook;

